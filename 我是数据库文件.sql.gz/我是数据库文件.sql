-- MySQL dump 10.13  Distrib 8.4.3, for Linux (x86_64)
--
-- Host: localhost    Database: work_helper
-- ------------------------------------------------------
-- Server version	8.4.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assignments`
--

DROP TABLE IF EXISTS `assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assignments` (
  `assignment_id` int NOT NULL AUTO_INCREMENT,
  `teacher_id` int NOT NULL,
  `class_id` int NOT NULL,
  `subject` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `assignment_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`assignment_id`),
  KEY `teacher_id` (`teacher_id`),
  KEY `class_id` (`class_id`),
  CONSTRAINT `assignments_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`),
  CONSTRAINT `assignments_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignments`
--

LOCK TABLES `assignments` WRITE;
/*!40000 ALTER TABLE `assignments` DISABLE KEYS */;
INSERT INTO `assignments` VALUES (6,1,5,'物理','121212','2025-01-21'),(7,1,5,'信息技术','8848','2025-01-21'),(8,4,8,'英语','111','2025-01-21'),(9,4,8,'化学','2123123213133112\r\nfdkdsjfksdj\r\n你好','2025-01-21'),(10,5,8,'数学','12','2025-01-21'),(12,4,8,'物理','21212','2025-01-21'),(13,1,5,'英语','Ty','2025-01-21'),(14,1,5,'英语','1.练习册xxxx页\r\n2.背作文《xxxxxxxxxxx》','2025-01-22'),(15,1,5,'数学','1.练习册11111页\r\n2.抄写知识点\r\n3。121221','2025-01-22'),(16,1,5,'历史','3.1212121211\r\n1\r\n1','2025-01-22'),(17,1,5,'地理','3.1415926','2025-01-22'),(18,1,5,'语文','eworioureqoqiuwre','2025-01-22'),(19,1,5,'信息技术','没有作业','2025-01-22'),(20,1,5,'音乐','重写《》','2025-01-22'),(21,1,5,'生物','1+1=2.','2025-01-22');
/*!40000 ALTER TABLE `assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `classes` (
  `class_id` int NOT NULL AUTO_INCREMENT,
  `class_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `class_token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `class_headteacher` int NOT NULL,
  `class_teacher` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`class_id`),
  KEY `class_headteacher` (`class_headteacher`),
  KEY `class_teacher` (`class_teacher`),
  CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`class_headteacher`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes`
--

LOCK TABLES `classes` WRITE;
/*!40000 ALTER TABLE `classes` DISABLE KEYS */;
INSERT INTO `classes` VALUES (5,'测试班级','218c00c43408c92cb2b16afb986b6a87',1,'[2]'),(6,'测试班级','d158398f7c9c177f2ba4b1e9faf36070',1,'[2]'),(7,'test798','e3359a440d3c9db16036bcb7ac138b5b',3,NULL),(8,'test12333','5698f23aa4fb3c8e00c9564dd6989d62',4,'[5]');
/*!40000 ALTER TABLE `classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `code`
--

DROP TABLE IF EXISTS `code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `code` (
  `code_id` int NOT NULL AUTO_INCREMENT,
  `class_id` int NOT NULL,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_used` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`code_id`),
  KEY `class_id` (`class_id`),
  CONSTRAINT `code_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `code`
--

LOCK TABLES `code` WRITE;
/*!40000 ALTER TABLE `code` DISABLE KEYS */;
INSERT INTO `code` VALUES (8,5,'a31be8b60d7df23e08b7eb131bb1024c','2025-01-21 06:49:35',0),(9,8,'cba77a747316914faf70aea18e810898','2025-01-21 10:03:20',1);
/*!40000 ALTER TABLE `code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher_subjects`
--

DROP TABLE IF EXISTS `teacher_subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teacher_subjects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `class_id` int NOT NULL,
  `teacher_id` int NOT NULL,
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `class_id` (`class_id`),
  KEY `teacher_id` (`teacher_id`),
  CONSTRAINT `teacher_subjects_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`),
  CONSTRAINT `teacher_subjects_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher_subjects`
--

LOCK TABLES `teacher_subjects` WRITE;
/*!40000 ALTER TABLE `teacher_subjects` DISABLE KEYS */;
INSERT INTO `teacher_subjects` VALUES (9,5,1,'[\"\\u6570\\u5b66\",\"\\u8bed\\u6587\",\"\\u82f1\\u8bed\",\"\\u7269\\u7406\",\"\\u5316\\u5b66\",\"\\u751f\\u7269\",\"\\u5386\\u53f2\",\"\\u5730\\u7406\",\"\\u97f3\\u4e50\",\"\\u4fe1\\u606f\\u6280\\u672f\"]'),(11,5,3,'[\"\\u7269\\u7406\"]'),(12,8,4,'[\"\\u7269\\u7406\",\"\\u5316\\u5b66\",\"\\u4fe1\\u606f\\u6280\\u672f\"]'),(13,8,5,'[\"\\u6570\\u5b66\",\"\\u82f1\\u8bed\"]');
/*!40000 ALTER TABLE `teacher_subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `qq_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `register_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `classes` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subjects` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `qq_email` (`qq_email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'zhaishis','zhaishis@cmds.tech','$2y$10$5Ijkqywp/pMrp/jFrsC9Pe1xdSEmorY/wZbqPX1DmoiQF/tszD/NG','2025-01-20 08:51:30','[\"5\",\"6\",\"9\"]','[\"\\u6570\\u5b66\",\"\\u8bed\\u6587\",\"\\u82f1\\u8bed\",\"\\u7269\\u7406\",\"\\u5316\\u5b66\",\"\\u751f\\u7269\",\"\\u5386\\u53f2\",\"\\u5730\\u7406\",\"\\u97f3\\u4e50\",\"\\u4fe1\\u606f\\u6280\\u672f\"]','650541de571091d6b932c40e94cfbf14'),(2,'TenShine','sevenen@ighx.me','$2y$10$b6BbFEbYCrcd1u4hPi/foOm8572bSmM5dctCgMBU6MA4cx6VVWQse','2025-01-20 12:54:19','[\"6\",5]',NULL,NULL),(3,'u','a001@3t.lol','$2y$10$XvApRTt1BmNqZitXBJcwiuh8aPVTLqXX.o6LlDOaSfzmmw6xSchn.','2025-01-20 17:29:46','[\"7\"]','[\"\\u7269\\u7406\"]',NULL),(4,'2010tcsy','169591476@qq.com','$2y$10$gGyD5VHc5v8.mHZGuHV5qeEG.eAUlAQp1R0dLU/MVpicpPMxl8mGy','2025-01-21 10:02:14','[\"8\"]','[\"\\u82f1\\u8bed\",\"\\u7269\\u7406\",\"\\u5316\\u5b66\",\"\\u4fe1\\u606f\\u6280\\u672f\"]',NULL),(5,'111','111@qq.com','$2y$10$vp77XbfBZrQfW8DuECpisOvtplgyO4qVdSy6A7GY403Dxp3MpHeAi','2025-01-21 10:04:36','[8]','[\"\\u6570\\u5b66\",\"\\u8bed\\u6587\",\"\\u82f1\\u8bed\",\"\\u7269\\u7406\"]',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-26 16:11:50
